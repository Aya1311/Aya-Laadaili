#include<iostream>
using namespace std;
class Shape{
    private :
    int haut;
    int large;
    public:
    Shape(){
        cout<<"je suis le const par defaut"<<endl;
    }
    Shape(int h,int l){
        this->haut =h;
        this->large =l;
    }  
};
class Triangle : public Shape {
      public:
      void area(int l, int h){
        int at;//l'aire du triangle 
        at=(l+h)/2;
        cout<<"l'aire est:"<<at<<endl;
      }
};
class Rectangle : public Shape {
      public:
    void area(int l, int h){
        int ar;//l'aire du rectangle
        ar=l*h;
        cout<<"l'aire est:"<<ar<<endl;
    }
};
int main(){
    Rectangle r;
    Triangle t;
    r.area(4,5);
    t.area(3,2);
    return 0;
}