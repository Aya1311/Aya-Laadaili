#include<iostream>
using namespace std;
class MyClass{
   public:
   string txt1;
   string txt2;
   MyClass();
   ~MyClass();
   void fct1(){
    cout<<" ecrire le texte :"<<endl;
    cin>>txt1;
    cout<<"le premier texte est :"<<txt1<<endl;
   }
   void fct2(){
    cout<<" ecrire le deuxieme texte :"<<endl;
    cin>>txt2;
    cout<<"le deuxieme texte est :"<<txt2<<endl;
   }
};
MyClass :: MyClass(){
    cout<<"cons par defaut"<<endl;
}
MyClass :: ~MyClass(){
    cout<<"the end par destructeur"<<endl;
}
int main(){
    MyClass c1;
    c1.fct1();
    c1.fct2();
    return 0;

}