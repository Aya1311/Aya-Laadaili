#include<iostream>
using namespace std;
class Persone{
    private:
    string nom;
    string prenom;
    int date;
    public:
    Persone(){
        cout<<"const par defaut"<<endl;

    }
    Persone(string nom , string prenom,int date){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
    }
    void afficher(){
        cout<<"le nom est "<<nom<<endl;
        cout<<"le prenom est "<<prenom<<endl;
        cout<<"le date de naissance  est "<<date<<endl;
    }
};
class Employee : public Persone
{

public:
    string nom;
    string prenom;
    int date;
    int salaire;
    Employee(){
         cout<<"const par defaut"<<endl;
    }
    void afficher(string prenom ,string nom , int date , int salaire){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        this->salaire=salaire;

        cout<<"le nom est :"<<nom<<endl;
        cout<<"le prenom est :"<<prenom<<endl;
        cout<<"le date de naissance  est :"<<date<<endl;
        cout<<"le salaire est :"<<salaire<<endl;
    }
};
class Chef : public  Employee
{

public: 
    string nom;
    string prenom;
    int date;
    int salaire;
    string service;
    Chef(){
         cout<<"const par defaut"<<endl;
    }
    void afficher(string prenom ,string nom , int date , int salaire,string service){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        this->service=service;
        this->salaire=salaire;

        cout<<"le nom est :"<<nom<<endl;
        cout<<"le prenom est :"<<prenom<<endl;
        cout<<"le date de naissance  est :"<<date<<endl;
        cout<<"le service est :"<<service<<endl;
        cout<<"le salaire est :"<<salaire<<endl;
    }
};
class Directeur : public Chef
{

public:
    string nom;
    string prenom;
    int date;
    int salaire;
    string service;
    string sa;//societe acompagne
    Directeur(){
         cout<<"const par defaut"<<endl;
    }
   void afficher(string prenom ,string nom , int date , int salaire ,string service,string sa){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        this->service=service;
        this->sa=sa;
        this->salaire=salaire;

        cout<<"le nom est :"<<nom<<endl;
        cout<<"le prenom est :"<<prenom<<endl;
        cout<<"le date de naissance est :"<<date<<endl;
        cout<<"le service est :"<<service<<endl;
        cout<<"le salaire est :"<<salaire<<endl;
        cout<<"la societe acompagne  est :"<<sa<<endl;
    }
};
int main(){
    Persone p1("ismail","moughtanim",0232002);
    p1.afficher();
    Employee e1;
    e1.afficher("ismail","moughtanim",0232002,3400);
    Chef c1;
    c1.afficher("ismail","moughtanim",0232002,3400,"cuisiner");
    Directeur d1;
    d1.afficher("ismail","moughtanim",0232002,3400,"cuisiner","bricomma");
    return 0;
}