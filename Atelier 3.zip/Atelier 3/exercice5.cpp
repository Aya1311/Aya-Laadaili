#include<iostream>
using namespace std;
class Animal{
    public:
    string nom;
    int age;
    void set_value(){
        cout<<"je suis: "<<nom<<endl;
    }
};
class Zebra  : public Animal{
    public:
    string lo;//lieux d'origine
    void set_value(string nom , int age , string lo){
        this->age=age;
        this->lo=lo;
        this->nom=nom;
         cout<<"je suis: "<<nom<<"agee de "<<age<<"d'origine de "<<lo<<endl;
    }
};
class Dolphin : public Animal{
    public:
    string lo;//lieux d'origine
    void set_value(string nom , int age , string lo){
        this->age=age;
        this->lo=lo;
        this->nom=nom;
         cout<<"je suis: "<<nom<<"agee de "<<age<<"d'origine de "<<lo<<endl;
    }
};
int main(){
    Zebra z;
    Dolphin d;
    z.set_value("zebre",2,"senegale");
    d.set_value("dophin",2,"sud");
    return 0;
}