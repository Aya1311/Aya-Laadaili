#include<iostream>
using namespace std;
class Complex{
    public:
    int im1;
    int rl1;
    int im2;
    int rl2;
    int im;
    int rl;
Complex(){}
void donner1(){
    cout<<"veuillez donner la partie reel du nombre complexe 1 "<<endl;
    cin>>rl1;
    cout<<"veuillez donner la partie imaginaire nombre complexe 1  "<<endl;
    cin>>im1;
    cout<<"le nombre complex 1 est: "<<rl1<<"+i"<<im1<<endl;
}
void donner2(){
    cout<<"veuillez donner la partie reel nombre complexe 2 "<<endl;
    cin>>rl2;
    cout<<"veuillez donner la partie imaginaire nombre complexe 2 "<<endl;
    cin>>im2;
    cout<<"le nombre complex 2 est: "<<rl2<<"+i"<<im2<<endl;
}
void operator+(Complex){
    im1+=im2;
    rl1+=rl2;
    cout<<"le nombre complex  apres la sommation est: "<<rl1<<"+i"<<im1<<endl;
}
void operator-(Complex){
    im1-=im2;
    rl1-=rl2;
    cout<<"le nombre complex  apres la soustraction est: "<<rl1<<"+i"<<im1<<endl;
}
void operator*(Complex){
    im1=im1*im2;
    rl1=rl1*rl2;
    cout<<"le nombre complex  apres la multiplication est: "<<rl1<<"+i"<<im1<<endl;
}
void operator/(Complex){
    im1=im1/im2;
    rl1=rl1/rl2;
    cout<<"le nombre complex  apres la division est: "<<rl1<<"+i"<<im1<<endl;
}
};
int main(){
    Complex c1;
    Complex c2;
    c1.donner1();
    c2.donner2();
    c1+c2;
    c1-c2;
    c1*c2;
    c1/c2;
   return 0;
}