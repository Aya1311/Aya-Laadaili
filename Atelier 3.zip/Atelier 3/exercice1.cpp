#include<iostream>
using namespace std;
class Mere
{
private:
int a;
public:
   void display(){
    cout<<"class  mere"<<endl;
   }
};

class Fille : public Mere {
   int b;
public:
     void display(){
        cout<<"class fille"<<endl;
     }  
};


int main(){
    Fille f1;
     f1.display();
     return 0;
}